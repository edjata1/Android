package com.example.edjata.highlowdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Random randomGenerator = new Random();
    int randomNumber = randomGenerator.nextInt(20)+1;

    public void makeToast(String stringMsg){

        Toast.makeText(MainActivity.this, stringMsg, Toast.LENGTH_LONG).show();

    }

    public void myGuessBtn(View view){

        EditText userInput = (EditText)findViewById(R.id.userInputEditText);

        int userInputNum = Integer.parseInt(userInput.getText().toString());


        if (userInputNum != randomNumber){

            Toast.makeText(this, "You guessed "+ userInputNum, Toast.LENGTH_LONG).show();

            //clear editText view
            ((EditText) findViewById(R.id.userInputEditText)).setText("");

            if (userInputNum > randomNumber){
                makeToast("Go Lower, Ha-Ha, LMAO");

            }else{
                makeToast("Go Higher, Ha-Ha-Ha, Smh");
            }
        }
        else
            {
            Toast.makeText(this, "Right # GURU, "+ randomNumber +" was picked. Try Again!!", Toast.LENGTH_LONG).show();
            ((EditText) findViewById(R.id.userInputEditText)).setText("");
            randomNumber = randomGenerator.nextInt(20)+1;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


}
